import pandas as pd 
import matplotlib.pyplot as plt
import networkx as nx
from matplotlib.pyplot import figure
import statistics
import copy
#a

def old_edge_graph(filename):
    """
    reads the "old_edges.txt" and creates a graph using NetworkX
    """

    # g = nx.read_edgelist(filename, delimiter='\t', nodetype=str)

    df = pd.read_csv(filename, header = None, sep='\t')

    df.columns = ["Author_1", "Author_2"]

    G = nx.Graph()

    g = nx.from_pandas_edgelist(df, "Author_1", "Author_2", create_using=G)

    figure(figsize=(20,20))

    nx.draw_shell(g, with_labels=True)

    plt.show()

    return g

old_g = old_edge_graph("/Users/Andrew/Desktop/CS506/HW3/cs506-homework-3-SunkCostSong/old_edges.txt")

# print(nx.info(old_g))

#b

def track_new_edge(filename):
    """ 
    reads the file "new_edges.txt" and for each author, keeps track of the new collaborations
    """

    df = pd.read_csv(filename, header = None, sep='\t')

    df.columns = ["Author_1", "Author_2"]

    G = nx.MultiGraph()

    g = nx.from_pandas_edgelist(df, "Author_1", "Author_2", create_using=G)

    return g

new_g = track_new_edge("/Users/Andrew/Desktop/CS506/HW3/cs506-homework-3-SunkCostSong/new_edges.txt")

#c

filtered_g = new_g.copy()

for node in new_g.nodes:

    if new_g.degree[node] < 10:

        filtered_g.remove_node(node)

def common_friends_number(G, X):
    """ 
    takes a given G and an author X and returns a list of reccomendations for X
    sorted by the number of common neighbors they have with X
    """

    recommendations = []

    num_neighbors_list = []

    for node in filtered_g:

        if G.has_edge(node, X) == False and node != X:

            num_neighbors = len(sorted(nx.common_neighbors(G, node, X)))

            if num_neighbors > 0:       #ignores nodes with zero common neighbors

                recommendations.append(node)

                num_neighbors_list.append(num_neighbors)

    if recommendations != [] and num_neighbors_list != []:

        num_neighbors_list, recommendations = (list(t) for t in zip(*sorted(zip(num_neighbors_list, recommendations), reverse=True)))

    return recommendations
    
# common_friends = common_friends_number(old_g, "Adrian Weller")

# print(common_friends)

#d

def jaccard_index(G, X):
    """
    given G and an author X, returns a list of recommendations for X sorted by the number of 
    their Jaccard Index with respect to X
    """

    recommendations = []

    jaccard_score_list = []

    for node in filtered_g:

        if G.has_edge(node, X) == False and node != X:

            jaccard_score = list(nx.jaccard_coefficient(G, [(node, X)]))[0][2]

            if jaccard_score> 0:    #ignores nodes with zero jaccard score

                recommendations.append(node)

                jaccard_score_list.append(jaccard_score)

    if recommendations != [] and jaccard_score_list != []:

        jaccard_score_list, recommendations = (list(t) for t in zip(*sorted(zip(jaccard_score_list, recommendations), reverse=True)))

    return recommendations

# jaccard_friends = jaccard_index(old_g, "Adrian Weller")

#e

def adamic_adar_index(G, X):
    """
    given G and an author X, returns a list of recommendations for X sorted by the number of 
    their Adamic/Adar Index with respect to X
    """

    recommendations = []

    adamic_adar_score_list = []

    for node in filtered_g:

        if G.has_edge(node, X) == False and node != X:

            adamic_adar_score = list(nx.adamic_adar_index(G, [(node, X)]))[0][2]

            if adamic_adar_score> 0:    #ignores nodes with zero adamic adar index

                recommendations.append(node)

                adamic_adar_score_list.append(adamic_adar_score)

    if recommendations != [] and adamic_adar_score_list != []:

        adamic_adar_score_list, recommendations = (list(t) for t in zip(*sorted(zip(adamic_adar_score_list, recommendations), reverse=True)))

    return recommendations

# adamic_adar_friends = adamic_adar_index(old_g, "Adrian Weller")

#f

common_avg_accuracy = []

jaccard_avg_accuracy = []

adamic_adar_avg_accuracy = []

for node in filtered_g:

    common = common_friends_number(old_g, node)

    if len(common) > 10:

        common = common[:10]

    jaccard = jaccard_index(old_g, node)

    if len(jaccard) > 10:

        jaccard = jaccard[:10]

    adamic_adar = adamic_adar_index(old_g, node)

    if len(adamic_adar) > 10:

        adamic_adar = adamic_adar[:10]

    common_accuracy = 0

    jaccard_accuracy = 0

    adamic_adar_accuracy = 0

    for connection in new_g[node]:

        if connection in common:

            common_accuracy += 1
        
        if connection in jaccard:

            jaccard_accuracy += 1

        if connection in adamic_adar:

            adamic_adar_accuracy += 1

    if len(common) == 0:

        common_avg_accuracy.append(0)  

    else:

        common_avg_accuracy.append(common_accuracy/len(common))

    if len(jaccard) == 0:

        jaccard_avg_accuracy.append(0)

    else:

        jaccard_avg_accuracy.append(jaccard_accuracy/len(jaccard))

    if len(adamic_adar) == 0:

        adamic_adar_avg_accuracy.append(0)

    else:

        adamic_adar_avg_accuracy.append(adamic_adar_accuracy/len(adamic_adar))

print("The accuracy of common friends is :", statistics.mean(common_avg_accuracy))

print("The accuracy of jaccard index is :", statistics.mean(jaccard_avg_accuracy))

print("The accuracy of adamic adar index is :", statistics.mean(adamic_adar_avg_accuracy))

#The accuracy of common friends is : 0.23945578231292516
#The accuracy of jaccard index is : 0.23537414965986395
#The accuracy of adamic adar index is : 0.23537414965986395

avg_rank_of_new_edges = []

for node in filtered_g:

    node_rank = []

    common = common_friends_number(old_g, node)

    jaccard = jaccard_index(old_g, node)

    adamic_adar = adamic_adar_index(old_g, node)

    for new_collab in new_g[node]:

        avg_calc = []

        if new_collab in common:

            common_rank = common.index(new_collab) + 1

            avg_calc.append(common_rank)

        if new_collab in jaccard:

            jaccard_rank = jaccard.index(new_collab) + 1

            avg_calc.append(jaccard_rank)

        if new_collab in adamic_adar:

            adamic_adar_rank = adamic_adar.index(new_collab) + 1

            avg_calc.append(adamic_adar_rank)

        if len(avg_calc) == 0:

            node_rank.append([new_collab, 0])

        else:

            avg_node_rank = statistics.mean(avg_calc)

            node_rank.append([new_collab, avg_node_rank])

    node_rank.sort(key = lambda x: x[1], reverse = False)

    for index in range(len(node_rank)):

        count = 0       #counter to prevent infinite loop 

        if node_rank[0][1] == 0 and count < len(node_rank[index]):

            temp = node_rank.pop(0)

            node_rank.append(temp)

            count += 1

    node_rank[0].append(1)

    for ranking in range(1, len(node_rank)):

        if node_rank[ranking][1] == node_rank[ranking - 1][1]:

            node_rank[ranking].append(node_rank[ranking - 1][2])

        else:

            node_rank[ranking].append(ranking + 1)
    
    avg_rank_of_new_edges.append([node, node_rank])

print(avg_rank_of_new_edges)

# for each list in avg_rank_of_new_edges, the first value of that list is an author (let's call it author 1) from new_edges.txt that has at least 10 new collaborations
# and the second value of that list is a second list where in the second list, the first value is an author (let's call it author 2) that author 1 has acutally
# collaborated with, the second value is the average rank based on author 2's index in each of the 3 lists of recommendations, 
# and the third value is the relative ranking of author 2 (starting from rank = 1) based on the average ranking (the value before this) for all author 2s that author 1 has collaborated with in new_edges.txt
