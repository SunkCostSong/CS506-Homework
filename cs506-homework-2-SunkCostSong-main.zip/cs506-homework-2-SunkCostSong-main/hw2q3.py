from sklearn.decomposition import PCA
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from sklearn.pipeline import make_pipeline 
from sklearn.preprocessing import StandardScaler
import time
import copy
import statistics

#a

X = np.load("/Users/Andrew/Desktop/CS506/HW2/cs506-homework-2-SunkCostSong/mnist_data.npy")

Y = np.load("/Users/Andrew/Desktop/CS506/HW2/cs506-homework-2-SunkCostSong/mnist_labels.npy")

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=200, random_state=69)

pca = PCA()

pca.fit(X)

#b

num_components = [25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450, 475, 500]

explained_variance = []

pca_deepcopy_X = copy.deepcopy(X)

for comp in num_components:

    z = PCA(n_components=comp)

    explained_variance.append(z.fit(pca_deepcopy_X).explained_variance_ratio_.sum())

plt.plot(num_components, explained_variance, label = "explained variance")

plt.xlabel('n components')

plt.ylabel('explained variance')

plt.title('Explained Variance vs. N Components')

plt.legend()

plt.show()

#c

#It appears that the optimal number of components would be 200. The explained variance at 200 is about 95% and anything above 200 increases the explained variance 
# less and less each time. I feel that at 200, it is worth the tradeoff between number of components and faster classification performance.

pca_deepcopy_X = copy.deepcopy(X)

pca_deepcopy_Y = copy.deepcopy(Y)

pca_size = make_pipeline(StandardScaler(), PCA(n_components=200))

pca_size.fit(pca_deepcopy_X,pca_deepcopy_Y)

X_train, X_test, Y_train, Y_test = train_test_split(pca_deepcopy_X, pca_deepcopy_Y, test_size=1/5, random_state=69)

pca_knnmodel = KNeighborsClassifier(n_neighbors=17).fit(X_train, Y_train)

Y_train_prediction = pca_knnmodel.predict(X_train)

Y_test_prediction = pca_knnmodel.predict(X_test)

train_accuracy = accuracy_score(Y_train, Y_train_prediction)

test_accuracy = accuracy_score(Y_test, Y_test_prediction)

print("Train Accuracy: ",train_accuracy)
print("Test Accuracy: ",test_accuracy)

#Train accuracy of 0.9515
#Test accuracy of 0.9502

#d

shuffled_x, shuffled_y = shuffle(X, Y, random_state=69)

size = 3000

sample_sizes = []

sample_run_time = []

while (size <= len(X)):

    sample_deepcopy_X = copy.deepcopy(shuffled_x)

    sample_deepcopy_Y = copy.deepcopy(shuffled_y)

    print("sample size =", size)

    sample_sizes.append(size)

    st = time.time()

    KNeighborsClassifier(n_neighbors=17).fit(sample_deepcopy_X[:size], sample_deepcopy_Y[:size])

    et = time.time()

    size += 3000

    sample_run_time.append(et - st)

    print("run time =", (et - st))

plt.subplot(1, 2, 1)

plt.plot(sample_sizes, sample_run_time, label = "run_time")

plt.xlabel('sample size')

plt.ylabel('run time (seconds)')

plt.title('run time vs sample size')

plt.legend()

component_run_time = []

num_components = []

for i in range(50, 751, 100):

    component_deepcopy_X = copy.deepcopy(X)

    component_deepcopy_Y = copy.deepcopy(Y)

    model = make_pipeline(StandardScaler(), PCA(n_components=i)).fit(component_deepcopy_X,component_deepcopy_Y)

    st = time.time()

    pca_knn = KNeighborsClassifier(n_neighbors=17).fit(component_deepcopy_X,component_deepcopy_Y)

    et = time.time()

    pca_knn.fit(model.transform(component_deepcopy_X), component_deepcopy_Y)

    num_components.append(i)

    component_run_time.append(et - st)

    print("number of components =", i)

    print("run time =", (et - st), "seconds")

plt.subplot(1,2,2)

plt.plot(num_components, component_run_time, label = "run_time")

plt.xlabel('Number of Components')

plt.ylabel("run time (seconds)")

plt.title('run time vs number of components')

plt.legend()

plt.show()

#For both plots in general, as the sample size or the the number of components increase, fitting time increases.
#It seems that increasing the sample size 7 fold increases the run time approximately 8 fold (from sample size = 3000 to 21000).
#For number of components, it seems that increasing the number of components 7 fold increases the run time approximately 3 fold (from components = 107 to 750).
#Based on this, it appears that sample size affects the fitting time more.

#e

#optimal k = 17, optimal size = 12000. optimal components = 250

optimal_deepcopy_X = copy.deepcopy(X)

optimal_deepcopy_Y = copy.deepcopy(Y)

pca_size = make_pipeline(StandardScaler(), PCA(n_components=250))

pca_size.fit(optimal_deepcopy_X,optimal_deepcopy_Y)

st = time.time()

optimal_model = KNeighborsClassifier(n_neighbors=17).fit(optimal_deepcopy_X[:12000], optimal_deepcopy_Y[:12000])

et = time.time()

fastest_time = et - st

print("fastest time =", fastest_time)

check_sample_size = fastest_time < statistics.median(sample_run_time)

check_num_components = fastest_time < statistics.median(component_run_time)

print("Is the fastest time faster than 50 percent of the tested sample sizes? :", check_sample_size)

print("Is the fastest time faster than 50 percent of the tested number of components? :", check_num_components)

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=1/5, random_state=69)

most_accurate = KNeighborsClassifier(n_neighbors=17).fit(X_train, Y_train)

#predict via most accurate

Y_train_prediction = most_accurate.predict(X_train)

Y_test_prediction = most_accurate.predict(X_test)

train_accuracy = accuracy_score(Y_train, Y_train_prediction)

test_accuracy = accuracy_score(Y_test, Y_test_prediction)

#predict via accurate given faster than 50 percent

optimal_Y_train_prediction = optimal_model.predict(X_train)

optimal_Y_test_prediction = optimal_model.predict(X_test)

optimal_train_accuracy = accuracy_score(Y_train, optimal_Y_train_prediction)

optimal_test_accuracy = accuracy_score(Y_test, optimal_Y_test_prediction)

print("the most accurate train accuracy: ",train_accuracy)

print("the fastest train accuracy: ",optimal_train_accuracy)

print("the most accurate test accuracy: ",test_accuracy)

print("the fastest test accuracy: ",optimal_test_accuracy)

#My model given that it's faster than 50% of all tested models is 0.851% less accurate for the training set predictions and 0.295% less accurate for the testing set
#predictions than my most accurate model (k = 17, using all components, training set of 80%).

#most accurate train accuracy:  0.9514880952380952
#fastest train accuracy:  0.9433928571428571

#most accurate test accuracy:  0.9502380952380952
#fastest test accuracy:  0.9473809523809524





