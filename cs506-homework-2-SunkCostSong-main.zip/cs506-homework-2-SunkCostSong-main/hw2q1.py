import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors
import sklearn.datasets as datasets
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn import datasets, linear_model
import sklearn.linear_model
from mlxtend.plotting import plot_linear_regression

# without outlier
def generate_line_data():
    t, _ = datasets.make_blobs(n_samples=300, centers=[[0,0]], cluster_std=1, random_state=0)

    # create some space between the classes
    X = np.array(list(filter(lambda x : x[0] - x[1] < -.5 or x[0] - x[1] > .5, t)))

    Y = np.array([1 if x[0] - x[1] >= 0 else 0 for x in X])

    return X, Y

# with outlier
def generate_line_data_outlier():
    t, _ = datasets.make_blobs(n_samples=300, centers=[[0,0]], cluster_std=1, random_state=0)
    # create some space between the classes
    X = np.array(list(filter(lambda x : x[0] - x[1] < -.5 or x[0] - x[1] > .5, t)))

    outlier_x = np.random.uniform(low=6, high=8, size=(30,))

    outlier_y = np.random.uniform(low=-6, high=-4, size=(30,))

    merged = np.column_stack((outlier_x,outlier_y))

    X = np.vstack((X,merged))

    Y = np.array([1 if x[0] - x[1] >= 0 else 0 for x in X])

    return X, Y

#data_without_outlier

data_without_outlier = generate_line_data()

cs = np.array([x for x in 'rb'])
cs = np.hstack([cs] * 20)

plt.xlim(-4,9)
plt.ylim(-8,4)
plt.scatter(data_without_outlier[0][:,0],data_without_outlier[0][:,1],color=cs[data_without_outlier[1]].tolist(), s=50, marker = 'x', alpha=0.8)

# Fit the data to a logistic regression model.
logreg = sklearn.linear_model.LogisticRegression(penalty='none', verbose=2, solver='sag')
logreg.fit(data_without_outlier[0], data_without_outlier[1])

# Retrieve the model parameters.
logb = logreg.intercept_[0]
logw1, logw2 = logreg.coef_.T

# Calculate the intercept and gradient of the decision boundary.
logc = -logb/logw2
logm = -logw1/logw2

#plot logistic regression line
xmin, xmax = -4, 8
ymin, ymax = -8, 4
xd = np.array([xmin, xmax])
yd = logm*xd + logc

# Create linear regression object
linreg = linear_model.LinearRegression()
linreg.fit(data_without_outlier[0], data_without_outlier[1])

# Retrieve the linear model parameters.
linb = linreg.intercept_
linw1, linw2 = linreg.coef_

# Calculate the linear intercept and gradient of the decision boundary.
linm = -linw1/linw2

#plot linear regression line
xmin, xmax = -4, 8
ymin, ymax = -8, 4
linxd = np.array([xmin, xmax])
linyd = linm*xd + linb

plt.plot(linxd, linyd, 'm', lw=1, ls='-')
plt.plot(xd, yd, 'g', lw=1, ls='-')

plt.show()

#data_with_outlier

data_with_outlier = generate_line_data_outlier()

cs = np.array([x for x in 'rb'])
cs = np.hstack([cs] * 20)

plt.xlim(-4,9)
plt.ylim(-8,4)
plt.scatter(data_with_outlier[0][:,0],data_with_outlier[0][:,1],color=cs[data_with_outlier[1]].tolist(), s=50, marker = 'x', alpha=0.8)

# Fit the data to a logistic regression model.
logreg = sklearn.linear_model.LogisticRegression(penalty='none', verbose=2, solver='sag')
logreg.fit(data_with_outlier[0], data_with_outlier[1])

# Retrieve the model parameters.
logb = logreg.intercept_[0]
logw1, logw2 = logreg.coef_.T

# Calculate the intercept and gradient of the decision boundary.
logc = -logb/logw2
logm = -logw1/logw2

#plot logistic regression line
xmin, xmax = -4, 8
ymin, ymax = -8, 4
xd = np.array([xmin, xmax])
yd = logm*xd + logc

# Create linear regression object
linreg = linear_model.LinearRegression()
linreg.fit(data_with_outlier[0], data_with_outlier[1])

# Retrieve the linear model parameters.
linb = linreg.intercept_
linw1, linw2 = linreg.coef_.T

# Calculate the linear intercept and gradient of the decision boundary.
linm = -linw1/linw2

#plot linear regression line
xmin, xmax = -4, 8
ymin, ymax = -8, 4
linxd = np.array([xmin, xmax])
linyd = linm*xd + linb

plt.plot(linxd, linyd, 'm', lw=.5, ls='-')
plt.plot(xd, yd, 'g', lw=.5, ls='-')

plt.show()


#c

# Yes, I got the same results as figure 1
# logistic regression only takes into consideration data points that are close to the decision boundary and thus, outliers don't really impact the placement of
# the decision boundary. Linear regression takes into account all points and thus, outliers will make the mean greater or less than a mean that is more representative of the
# data (these differences due to the outliers are amplified via squared differences). 
