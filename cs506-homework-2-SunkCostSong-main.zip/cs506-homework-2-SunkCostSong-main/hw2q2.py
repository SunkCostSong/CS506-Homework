import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt

#a
X = np.load("/Users/Andrew/Desktop/CS506/HW2/cs506-homework-2-SunkCostSong/mnist_data.npy")

Y = np.load("/Users/Andrew/Desktop/CS506/HW2/cs506-homework-2-SunkCostSong/mnist_labels.npy")

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=1/5.0, random_state=69)

#b
logmodel = LogisticRegression(multi_class = "multinomial", solver='sag').fit(X_train, Y_train)

Y_train_prediction = logmodel.predict(X_train)

Y_test_prediction = logmodel.predict(X_test)

print("Accuracy of training set = ", accuracy_score(Y_train, Y_train_prediction))

print("Accuracy of testing set = ", accuracy_score(Y_test, Y_test_prediction))

# Prediction for Y train has an accuracy score of 0.9675
# prediction for Y test has an accuracy score of 0.9188

#c

n = []

train_accuracy = []

test_accuracy = []

for i in range(1, 26, 2):

    knnmodel = KNeighborsClassifier(n_neighbors=i).fit(X_train, Y_train)

    Y_train_prediction = knnmodel.predict(X_train)

    Y_test_prediction = knnmodel.predict(X_test)

    print("Now running n = ", i)

    n.append(i)

    train_accuracy.append(accuracy_score(Y_train, Y_train_prediction))

    test_accuracy.append(accuracy_score(Y_test, Y_test_prediction))

plt.plot(n, train_accuracy, label = "train accuracy")

plt.plot(n, test_accuracy, label = "test accuracy")

plt.xlabel('n neighbors')

plt.ylabel('accuracy score')

plt.title('Accuracy Score vs N Neighbors')

plt.legend()

plt.show()

#d

#The obvious pattern is that for both train and test accuracy scores, as k neighbors increases, the accuracy score decreases at a decreasing rate. 
#k = 1 has the highest accuracy score because it is underfitting the model. 
#The difference between training accuracy and testing accuracy seems to decrease as K increases.
#K = 17 seems optimal as it has the lowest difference between train and test accuracy while maintaining an accuracy of 0.95 and above

#e

sub_set = 3000

train_size = []

train_accuracy = []

test_accuracy = []

while (sub_set <= len(X_train)):

    print("train size = ", sub_set)

    X_train_subset = X_train[:sub_set]

    Y_train_subset = Y_train[:sub_set]

    knnmodel = KNeighborsClassifier(n_neighbors=17).fit(X_train_subset, Y_train_subset)

    Y_train_prediction = knnmodel.predict(X_train_subset)

    Y_test_prediction = knnmodel.predict(X_test)

    train_accuracy.append(accuracy_score(Y_train_subset, Y_train_prediction))

    test_accuracy.append(accuracy_score(Y_test, Y_test_prediction))

    train_size.append(sub_set)

    if sub_set == len(X_train):

        break

    if (sub_set + 3000) > len(X_train):

        sub_set = len(X_train)

    else:

        sub_set += 3000

plt.plot(train_size, train_accuracy, label = "train accuracy")

plt.plot(train_size, test_accuracy, label = "test accuracy")

plt.xlabel('x_train sample size')

plt.ylabel('accuracy score')

plt.title('Accuracy Score vs. training set size')

plt.legend()

plt.show()

#f

#pros of logistic
#1. Easy to implement, interpret, and train (also efficient at it) for large datasets
#2. Provides direction of association between the outcomes and its predictors

#cons of logistic
#1. Inability to solve non-linear classification problems
#2. Vulnerable to overfitting especially for high dimensional datasets 

#pros of linear
#1. Efficient at computations and predictions for large datasets
#2. easy to interpret changes in the output relative to the predictor variable

#cons of linear
#1. sensitive to outliers as it takes into account all points for the calculation of the mean (errors are amplified via squared differences)
#2. inability to generate a good model to describe non-linear relationships between variables

#pros of knn
#1. Requires no assumptions for data set (e.g. linear independence)
#2. Can be used for both classification and regression problems

#cons of knn
#1. Does not work well for large datasets because it becomes more and more computationally expensive
#2. Does not work well as the dimensions of the data set increases

#We should use logistic regression over linear regression when we are trying to solve a classification problem because logistic regression is less 
#sensitive to outliers in which would not heavily impact the classification of data. 

