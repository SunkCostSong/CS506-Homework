import random

from hw0q4 import *
#a

def train_test_split(X, y, t_f):
    """takes as input the fraction, t_f, of a data set that will be used to test the set and randomly splits the dataset, X, y, into train and test sets and returns 2 sets per X and y
    that are divided into test and train"""

    shuffled_set = list(zip(X, y)) 

    random.shuffle(shuffled_set) 

    shuffled_X, shuffled_y = zip(*shuffled_set)

    split = round(t_f * len(X))

    X_test = shuffled_X[:split]

    X_train = shuffled_X[split:]

    y_test = shuffled_y[:split]

    y_train = shuffled_y[split:]

    return X_train, y_train, X_test, y_test


#b

def train_test_CV_split(X, y, t_f, cv_f):
    """ divides the data set intp three sections which takes as input the fraction of the data set that will be used as the test set, t_f, and the fraction that will be used
    in the cross-validation set and returns 3 sets per X and y"""

    shuffled_set = list(zip(X, y))

    random.shuffle(shuffled_set) #shuffles X and y simultaneously in the same way

    shuffled_X, shuffled_y = zip(*shuffled_set)

    test_split = (round(len(X) * t_f))

    validation_split = (round(len(X) * cv_f) + test_split)

    X_train = shuffled_X[validation_split:]

    y_train = shuffled_y[validation_split:]

    X_test = shuffled_X[:test_split]

    y_test = shuffled_y[:test_split]

    X_cv = shuffled_X[test_split:validation_split]

    y_cv = shuffled_y[test_split:validation_split]

    return X_train, y_train, X_test, y_test, X_cv, y_cv

#X = [[1, 2],[3, 4],[5, 6], [7, 8]]
#y = ["a", "b", "c", "d"]

#A = import_data("/Users/Andrew/Desktop/CS506/HW0/cs506-homework-0-SunkCostSong/train.csv")

#B = train_test_split(A[0], A[1], 0.498)
#print(B)
#print(len(B[0]))
#print(len(B[2]))

#C = train_test_CV_split(A[0], A[1], 0.45, 0.45)

#print(C)
#print(len(C[1]))
#print(len(C[3]))
#print(len(C[5]))