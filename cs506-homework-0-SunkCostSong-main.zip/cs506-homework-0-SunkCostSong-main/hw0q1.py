def import_data(filename):
    """ takes in a the variable, filename, a dataset returns two arrays, X and y, 
    where X contains the attribute for every patient and y contains the corresponding class"""

    #accumulator empty list that hodls each patient's attributes
    X = []

    #accumulator empty list that holds each patient's corresponding class
    y = []

    file = open(filename, "r")

    #list where each value is a string that represent's each line from the input, filename
    list_patients = file.readlines()

    for patient in list_patients:

        temp_X = []
        
        #turns the string, patient, into a list of strings based on commas in the original string, patient
        patient = patient.split(",")

        for value in range(len(patient) - 1): #excludes the class column
            
            if patient[value] == '?':

                temp_X = temp_X + [float("NaN")]

            else:

                temp_X = temp_X + [float(patient[value])]

        X = X + [temp_X] #adds the revised row into accumulator list, X

        if patient[-1] == '?': #checks patient class column
            
            y = y + [float("NaN")]

        else:

            y = y + [int(patient[-1])] #adds class to accumulator, y

    file.close
   
    return X, y

#m, n = import_data("/Users/Andrew/Desktop/CS506/HW0/cs506-homework-0-SunkCostSong/arrhythmia.data")
#print(len(m[0]))
#print(len(n))
#print(len(m[0][0]))
#print(m)