def import_data(filename):
    """ takes in the train.csv file and converts non-numerical data (gender, embarked category) into 
    numerical ones and returns it as an array """

    #accumulator variable for the attributes of each row from the input except survived
    X = []

    #accumulator variable for the 'survived' attributes of each row of the input
    y = []

    file = open(filename, "r")

    #skip the header
    next(file)

    #creates a list of strings where each string contains all of each passenger's attributes
    list_passengers = file.readlines()

    for passenger in list_passengers:

        #splits list by " , ", creates list of lists
        attribute_list = passenger.split(",")
                    
        attribute_list.pop(3) #removes name attribute

        attribute_list.pop(3) #removes name attribute

        attribute_list.pop(-2) #removes cabin attribute

        attribute_list.pop(-3) #removes ticket attribute

        if (attribute_list[3]) == "female":

            attribute_list[3] = 0
                
        elif (attribute_list[3]) == "male":

            attribute_list[3] = 1
            
        else:

            attribute_list[-1] = float("NaN") 

        if (attribute_list[-1]) == "C\n":

            attribute_list[-1] = 0

        elif (attribute_list[-1]) == "Q\n":
                    
            attribute_list[-1] = 1

        elif (attribute_list[-1]) == "S\n":
                    
            attribute_list[-1] = 2

        else:

            attribute_list[-1] = float("NaN") 

        for column in range(len(attribute_list)):

            if attribute_list[column] == '': #checks for any remaining '' in list

                attribute_list[column] = float("NaN")

            elif isinstance(attribute_list[column], str):

                if (float(attribute_list[column]) % 1 == 0): #checks if float

                    attribute_list[column] = int(attribute_list[column])
                
                else:

                    attribute_list[column] = float(attribute_list[column])

        y = y + [(attribute_list[1])] #adds sruvived attribute to list: y

        attribute_list.pop(1) #removes survived attribute after adding

        X = X + [attribute_list]

    file.close

    return X, y

#print(import_data("/Users/Andrew/Desktop/CS506/HW0/cs506-homework-0-SunkCostSong/train.csv"))

#m = import_data("/Users/Andrew/Desktop/CS506/HW0/cs506-homework-0-SunkCostSong/train.csv")
#print(len(m[1]))
#n = 0
#for i in m[0]:
    #for j in range(len(i)):
        #if i[j] == '':
            #n += 1

#print(n)
            









