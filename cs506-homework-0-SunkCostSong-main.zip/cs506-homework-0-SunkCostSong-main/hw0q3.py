from hw0q1 import *

from hw0q2 import *

#a

import random

def shuffle_data( X, y):
    """ shuffles the order of data entries (the rows of X and y) and returns new shuffled arrays """

    random_list = random.sample(range(len(y)), len(y)) #chooses len(y) numbers from a list of integers from 0 to len(y) - 1, no repeats

    shuffled_X = []

    shuffled_y = []

    for number in random_list:

        shuffled_X = shuffled_X + [X[number]] #chooses a number from random_list and uses that number to index X and y

        shuffled_y = shuffled_y + [y[number]]

    return shuffled_X, shuffled_y
        
#b

def compute_std(X):
    """ takes in an array X and returns a list containing the standard deviation of each column in X"""

    stdev_list = []

    var_list = variance(X) #list of variance for each column of X

    for value in var_list:

        stdev_list = stdev_list + [value**(1/2)]

    return stdev_list

def mean(X):
    """ takes in an array X and returns a list containing the mean of each column in X """

    mean_list = []

    for column in range(len(X[0])):
        
        column_mean = 0

        for row in range(len(X)):

            column_mean += X[row][column]
        
        column_mean = column_mean / len(X)
    
        mean_list = mean_list + [column_mean]
    
    return mean_list


def variance(X):
    """ takes in an array X and returns a list containing the variance of each column in X"""

    variance_list = []

    list_mean = mean(X) #list of mean for each column of X

    for column in range(len(X[0])):
         
         sum_of_sq_diff = 0

         for row in range(len(X)):

             diff = X[row][column] - list_mean[column]

             sq_diff = diff**2

             sum_of_sq_diff += sq_diff
        
         var = sum_of_sq_diff / (len(X) - 1)

         variance_list = variance_list + [var]

    return variance_list

#c

def remove_outlier(X, y):
    """ removes all entries that contain a feature that is more than 2 standard deviations from the mean
    of that feature """

    #acuumulator for revised version of X
    removed_X = []

    #accumulator for revised version of y
    removed_y = []

    list_stdev = compute_std(X)

    list_mean = mean(X)

    for row in range(len(X)):
        
        #Used to create a deep copy of each row in X
        new_row = []

        for column in range(len(X[row])):

            if (list_mean[column] - (2 * list_stdev[column])) <= (X[row][column]) <= (2 * list_stdev[column] + list_mean[column]): #checking if above/below 2 stdev from the mean

                new_row = new_row + [X[row][column]]
        
        if len(new_row) == len(X[0]): #if both equal length, then no attribites were 2 stdev away from mean

            removed_X = removed_X + [new_row]

            removed_y = removed_y + [y[row]]
    
    return removed_X, removed_y

#d

def standardize_data(X):
    """ takes in an array X and returns an array where all data points are standardized """

    standardized_X = []

    list_mean = mean(X)

    list_stdev = compute_std(X)

    for row in X:

        new_row = []

        for column in range(len(row)):

            if list_stdev[column] == 0: #takes care of instances if the column's number are the same, i.e. stdev of 0

                new_row = new_row + [(row[column] - list_mean[column])] #mean and the value at row,column, would be the same. standardizing each value would = 0

            else:
                standardize = (row[column] - list_mean[column]) / list_stdev[column]

                new_row = new_row + [standardize]
        
        standardized_X = standardized_X + [new_row]

    return standardized_X

""" My version of standardized_data(X) has a time complexity of O(n * m). In terms of space complexity, it is also O(n * m)"""



#J = [[1, 2, 3], [1, 0, 0], [1, 1, 2], [1, 2, 2], [1, 1, 0]]

#K = [0, 1, 2 , 3, 4]

#print(shuffle_data(J, K))
#print(variance(J))
#print(compute_std(J))
#print (compute_std(J))
#print(remove_outlier(J, K))
#print(mean(J))
#print(compute_std(J))
#print(standardize_data(J))

#X = import_data("/Users/Andrew/Desktop/CS506/HW0/cs506-homework-0-SunkCostSong/arrhythmia.data")


#Y = impute_missing(X[0])

#Z = discard_missing(X[0], X[1])

#data_X = [[1, 2, 3, 7, 3], [4, 5, 7, 2, 7], [2, 9, 5, 3, 6], [2, 6, 3, 6, 3], [7, 3, 4, 8, 4]]
#data_y = [1, 5, 2, 7, 6]

#print(len(Z[0]))

#print(len(mean(Z[0])))

#print(len(compute_std(Z[0])))

#print(remove_outlier(Y, X[1]))

#print(remove_outlier(Z[0], Z[1]))

#M = remove_outlier(Z[0], Z[1])
#print(M)
#print(len(M[0]))
#print(len(M[1]))

#print(len(standardize_data(Z[0])))

#data_X = [[1, 4, 3, 7, 3], [4, 5, 7, 4, 7], [2, 9, 5, 3, 6], [2, 6, 3, 6, 3], [7, 3, 4, 8, 4]]
#data_y = [1, 5, 2, 7, 6]

#print(shuffle_data(data_X,data_y))

#print(compute_std(data_X))

#m = discard_missing(X[0], X[1])

#k = remove_outlier(m[0], m[1])

#print(len(k[0]))
#print(len(k[1]))

#print(standardize_data(data_X))

