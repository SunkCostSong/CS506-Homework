from hw0q1 import *

#a

def impute_missing(X):
    """ imputes missing entries, NaN, in the input with the median of the corresponding column in the input
    adn returns a new array with NaN values replaced with each column's median"""

    #accumulator list
    copy_X = []

    #contains the median for each column in X
    median_list = column_medians(X)

    for row in range(len(X)):
        
        #Used to create a deep copy of each row in X
        new_row = []

        for column in range(len(X[row])):

            if isNaN(X[row][column]): #if it is a NaN value, use median

                new_row = new_row + [median_list[column]]
            
            else:
                
                new_row = new_row + [X[row][column]]
        
        copy_X = copy_X + [new_row]
    
    return copy_X


def isNaN(value):
    """ checks if input is of type NaN and returns a boolean"""

    return (value != value) #NaN does not equal itself

def column_medians(X):
    """ takes in an array, X and returns a list of the medians of each column """

    #accumulator list to store the median of each column in X
    column_numbers = []

    for column in range(len(X[0])): #loop by column

        temp_list = []

        for row in X: #loop by row

            if isNaN(row[column]) == False: 

                temp_list = temp_list + [row[column]]
        
        temp_list = sorted(temp_list)

        length = len(temp_list)

        if (length % 2) != 0: #if there is remainder, then there are odd number of numbers

             column_numbers = column_numbers + [temp_list[length // 2]] #takes middle number if there are odd number of numbers
        
        else:

             average = (temp_list[length // 2] + temp_list[(length // 2) - 1 ]) / 2 #takes average if there are even number of numbers

             column_numbers = column_numbers + [average]

    return column_numbers

#b

""" median is less susceptible to long tails which may give a more accurate description of the
population's/sample population's average than using the mean. when computing the mean, long tails often 
make the mean too large/small which may not give an accurate description.

e.g. a sample population of [0, 50, 50, 100, 100, 100, 150, 150, 10000]

mean = 1188.9, median = 100

most of the values are clustered around the 0 to 150 range. the median is within that range. however, the 
mean gives too large of a value that it would not describe the sample population accurately. """


#c

def discard_missing (X, y):
    """ deals with missing entries, NaN, by discarding the entire row that has NaN in it, returns a 
    new array with those rows that contain NaN removed """

    #accumulator list for revised version of X
    copy_X = []

    #accumulator list for revised version of y
    copy_y = []

    for row in range(len(X)):
        
        new_row = []

        for column in range(len(X[row])):

            if isNaN(X[row][column]):

                break #if value is NaN, then new_row would have one less attribute per NaN than each row of X
            
            else:
                
                new_row = new_row + [X[row][column]]
        
        if len(new_row) == len(X[0]): #if the number of attributes are equal, then there was no NaN in that row

            copy_X = copy_X + [new_row]

            copy_y = copy_y + [y[row]]
    
    return copy_X, copy_y

#J = [[1, 2, float("NaN")], [0, 0, 0], [1, 1, 2], [2, 2, float("NaN")], [float("NaN"), float("NaN"), float("NaN")]]

#K = [1, 2 , 3, 4, 5]

#print(J)
#print(column_median(J))
#print(impute_missing(J))
#print(J)
#print(discard_missing(J, K))
#print(J, K)

#X = import_data("/Users/Andrew/Desktop/CS506/HW0/cs506-homework-0-SunkCostSong/arrhythmia.data")

#Y = impute_missing(X[0])

#Z = discard_missing(X[0], X[1])

#print(len(X[0]))
#print(len(Z[0]))
#print(len(Z[1]))
#print(len(Y))
#print(len(Y[0]))
#print(Y)

#data_X = [[1, float('nan'), 3, 7, 3], [4, 5, 7, 4, 7], [2, 9, 5, float('nan'), 6], [2, 6, 3, 6, 3], [7, 3, 4, 8, 4]]
#data_y = [1, 5, 2, 7, 6]

#print(impute_missing(data_X))

#print(discard_missing(data_X, data_y))