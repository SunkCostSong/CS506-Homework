import pandas as pd
from pandas import DataFrame
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import re

trainingSet = pd.read_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/train.csv")
testingSet = pd.read_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/test.csv")

# print("train.csv shape is ", trainingSet.shape)
# print("test.csv shape is ", testingSet.shape)

# print()

# print(trainingSet.head())
# print()
# print(testingSet.head())

# print()

# print(trainingSet.describe())

# trainingSet['Score'].value_counts().plot(kind='bar', legend=True, alpha=.5)
# plt.show()

#get an idea of how many unique items and other statistics for the column
# print("There are " + str(len(pd.unique(trainingSet['ProductId']))) + " unique items in the training set out of " + str(len(trainingSet['ProductId'])))

# print()

# #How many reviews per unique item

# print(trainingSet['ProductId'].value_counts())

# print()

# #finds the average rating per unique item

# print(trainingSet[["Score", "ProductId"]].groupby("ProductId").mean())

# print()

# #get an idea of how many unique users
# print("There are " + str(len(pd.unique(trainingSet['UserId']))) + " unique users in the training set out of " + str(len(trainingSet['UserId'])))

# print()

# #how many reviews per unique user

# print(trainingSet['UserId'].value_counts())

# print()

# #finds the average rating given by each unique user

# print(trainingSet[["Score", "UserId"]].groupby("UserId").mean())

# #check if all ProductId and UserId combinations are unique

# check_mults = trainingSet.groupby(["ProductId", "UserId"]).size().reset_index(name = "Freq")

# print(check_mults)

# print()

#average helpfulness numerator per score

print(trainingSet[["Score", "HelpfulnessNumerator"]].groupby("Score").mean())

print()

#average helpfulness numerator by unique user

print(trainingSet[["UserId", "HelpfulnessNumerator"]].groupby("UserId").mean())

print()

#average helpfulness numerator by unique item

print(trainingSet[["ProductId", "HelpfulnessNumerator"]].groupby("ProductId").mean())

print()

#average helpfulness numerator per score

print(trainingSet[["Score", "HelpfulnessNumerator"]].groupby("Score").mean())

print()

#evaluate avg score vs day of the week
trainingSet["Date"] = pd.to_datetime(trainingSet["Time"], unit = "s")

trainingSet['Day'] = trainingSet["Date"].dt.dayofweek

print(trainingSet[["Score", "Day"]].groupby("Day").mean())

#length of summary and text for each item

trainingSet["ReviewLength"] = trainingSet.apply(lambda row : len(row["Text"].split()) if type(row["Text"]) == str else 0, axis = 1)

trainingSet["SummaryLength"] = trainingSet.apply(lambda row : len(row["Summary"].split()) if type(row["Summary"]) == str else 0, axis = 1)

print(trainingSet["ReviewLength"])

print()

#avg length of text per score

print(trainingSet[["Score", "ReviewLength"]].groupby("Score").mean())

print()

#avg length of text per unique item

print(trainingSet[["ProductId", "ReviewLength"]].groupby("ProductId").mean())

print()

#avg length of text per unique user

print(trainingSet[["UserId", "ReviewLength"]].groupby("UserId").mean())

print()

#avg length of text per score

print(trainingSet[["Score", "ReviewLength"]].groupby("Score").mean())

print()

# print(trainingSet.where(trainingSet["Score"] == float(1))["Summary"].dropna().tolist())

# topWords = []

# stops  = set(stopwords.words('english'))

# for i in range(1, 6):

#     words = pd.Series(word_tokenize(" ".join(trainingSet.where(trainingSet["Score"] == float(i))["Summary"].dropna()))).str.lower()

#     words = words.str.replace(r'[^\w\s]+', '')

#     topWordsForScore = pd.Series([w for w in words if w not in stops]).value_counts()

#     print("Top 100 words for Score = ", i)

#     print(topWordsForScore.nlargest(100).index.tolist())

#     print()

#     topWords.append(topWordsForScore)

# for i in range(len(topWords)):

#     allExcepti = topWords[:i] + topWords[i + 1:] 

#     flattened = pd.concat(allExcepti)

#     topWords[i] = topWords[i].where(~topWords[i].index.isin(flattened.nlargest(100).index.tolist()))

#     print("Top 100 words sort of unique to Score = ", i + 1)

#     print(topWords[i].nlargest(100).index.tolist())

#     print()


# print(topWords)
#average rating per user and weigh it differently so that you end up with same number of each rating if chosen randomly
#how many reviews per user
#avg rating per item and weigh it differently so that you end up with same number of each rating if chosen randomly
#how many reviews per user
#categorize into 3: hate, indifferent, love based on key words used
#avg length of review for each score
#mean length of review

#weight function Sklearn libraries have a class-late parameter to weight the classes 


