import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, confusion_matrix
import numpy as np

X_train = pd.read_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/X_train.csv")

X_submission = pd.read_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/X_submission.csv")

#add AvgScorePerItem feature

AvgScorePerItem = X_train[["Score", "ProductId"]].groupby("ProductId").mean()

X_train = pd.merge(X_train, AvgScorePerItem, on = "ProductId", how = 'left')

X_train = X_train.rename(columns={'Score_x': 'Score', 'Score_y' : 'AvgScorePerItem'})

X_submission = pd.merge(X_submission, AvgScorePerItem, on = "ProductId", how = 'left')

X_submission = X_submission.rename(columns={'Score_x': 'Score', 'Score_y' : 'AvgScorePerItem'})

X_submission["AvgScorePerItem"] = X_submission["AvgScorePerItem"].replace(np.nan, 4)

#add AvgScorePerUser feature

AvgScorePerUser = X_train[["Score", "UserId"]].groupby("UserId").mean()

X_train = pd.merge(X_train, AvgScorePerUser, on = "UserId", how = 'left')

X_train = X_train.rename(columns={'Score_x': 'Score', 'Score_y' : 'AvgScorePerUser'})

X_submission = pd.merge(X_submission, AvgScorePerUser, on = "UserId", how = 'left')

X_submission = X_submission.rename(columns={'Score_x': 'Score', 'Score_y' : 'AvgScorePerUser'})

X_submission["AvgScorePerUser"] = X_submission["AvgScorePerUser"].replace(np.nan, 4)

#add AvgHelfulnessPerItem feature

AvgHelpfulnessPerItem = X_train[["HelpfulnessNumerator", "ProductId"]].groupby("ProductId").mean()

X_train = pd.merge(X_train, AvgHelpfulnessPerItem, on = "ProductId", how = 'left')

X_train = X_train.rename(columns={'HelpfulnessNumerator_x': 'HelpfulnessNumerator', 'HelpfulnessNumerator_y' : 'AvgHelpfulnessPerItem'})

X_submission = pd.merge(X_submission, AvgHelpfulnessPerItem, on = "ProductId", how = 'left')

X_submission = X_submission.rename(columns={'HelpfulnessNumerator_x': 'HelpfulnessNumerator', 'HelpfulnessNumerator_y' : 'AvgHelpfulnessPerItem'})

X_submission["AvgHelpfulnessPerItem"] = X_submission["AvgHelpfulnessPerItem"].replace(np.nan, 0)

#add AvgHelfulnessPerUser feature

AvgHelpfulnessPerUser = X_train[["HelpfulnessNumerator", "UserId"]].groupby("UserId").mean()

X_train = pd.merge(X_train, AvgHelpfulnessPerUser, on = "UserId", how = 'left')

X_train = X_train.rename(columns={'HelpfulnessNumerator_x': 'HelpfulnessNumerator', 'HelpfulnessNumerator_y' : 'AvgHelpfulnessPerUser'})

X_submission = pd.merge(X_submission, AvgHelpfulnessPerUser, on = "UserId", how = 'left')

X_submission = X_submission.rename(columns={'HelpfulnessNumerator_x': 'HelpfulnessNumerator', 'HelpfulnessNumerator_y' : 'AvgHelpfulnessPerUser'})

X_submission["AvgHelpfulnessPerUser"] = X_submission["AvgHelpfulnessPerUser"].replace(np.nan, 0)

print(X_train.columns)

print(X_submission.columns)

#add AvgReviewLengthPerItem feature

X_train["ReviewLength"] = X_train.apply(lambda row : len(row["Text"].split()) if type(row["Text"]) == str else 0, axis = 1)

AvgReviewLengthPerItem = X_train[["ProductId", "ReviewLength"]].groupby("ProductId").mean()

X_train = pd.merge(X_train, AvgReviewLengthPerItem, on = "ProductId", how = 'left')

X_train = X_train.drop(["ReviewLength_x"], axis = 1)

X_train = X_train.rename(columns={'ReviewLength_y' : 'AvgReviewLengthPerItem'})

X_submission = pd.merge(X_submission, AvgReviewLengthPerItem, on = "ProductId", how = 'left')

X_submission = X_submission.rename(columns={'ReviewLength' : 'AvgReviewLengthPerItem'})

X_submission['AvgReviewLengthPerItem'] = X_submission['AvgReviewLengthPerItem'].replace(np.nan, 0)

#add AvgReviewLengthPerUser feature

X_train["ReviewLength"] = X_train.apply(lambda row : len(row["Text"].split()) if type(row["Text"]) == str else 0, axis = 1)

AvgReviewLengthPerUser = X_train[["UserId", "ReviewLength"]].groupby("UserId").mean()

X_train = pd.merge(X_train, AvgReviewLengthPerUser, on = "UserId", how = 'left')

X_train = X_train.drop(["ReviewLength_x"], axis = 1)

X_train = X_train.rename(columns={'ReviewLength_y' : 'AvgReviewLengthPerUser'})

X_submission = pd.merge(X_submission, AvgReviewLengthPerUser, on = "UserId", how = 'left')

X_submission = X_submission.rename(columns={'ReviewLength' : 'AvgReviewLengthPerUser'})

X_submission['AvgReviewLengthPerUser'] = X_submission['AvgReviewLengthPerUser'].replace(np.nan, 0)

#add mostSimilarTo feature

topWords = []

stops  = set(stopwords.words('english'))

for i in range(1, 6):

    words = pd.Series(word_tokenize(" ".join(X_train.where(X_train["Score"] == float(i))["Summary"].dropna()))).str.lower()

    words = words.str.replace(r'[^\w\s]+', '')

    topWordsForScore = pd.Series([w for w in words if w not in stops]).value_counts()

    topWords.append(topWordsForScore)

top100Words = []

for i in range(len(topWords)):

    allExcepti = topWords[:i] + topWords[i + 1:] 

    flattened = pd.concat(allExcepti)

    topWords[i] = topWords[i].where(~topWords[i].index.isin(flattened.nlargest(100).index.tolist()))

    top100Words.append(topWords[i].nlargest(100).index.tolist())

top100Words[-1].remove("")

possible_scores = [1, 2, 3, 4, 5]

likelyScores = []

# textMostSimilarTo = {"Score" : [i + 1 for i in range(5)], "top100Words" : top100Words}

# text = pd.DataFrame(textMostSimilarTo, columns = ["Score", "top100Words"])

# X_train["LikelyScore"] = X_train.apply(lambda row : [len(list(set(row["Text"].split()).intersection(top))) for top in top100Words], axis = 1)

# print(X_train.columns)

#convert updated X_train and X_submission into csv 

X_train.to_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/X_train_new.csv")

X_submission.to_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/X_submission_new.csv")

#Use average length of text, top 100 words used, avg score per product, avg score per user, look for rating in text, avg helpfulness numerator per score

