import pandas as pd

prediction = pd.read_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/X_submission.csv")
prediction['Score'] = 4.0

submission = prediction[['Id', 'Score']]
print(submission.head())
submission.to_csv("/Users/Andrew/Desktop/CS506/CS506Midterm/kaggle-competition-SunkCostSong/starter-code/data/submission.csv", index=False)
