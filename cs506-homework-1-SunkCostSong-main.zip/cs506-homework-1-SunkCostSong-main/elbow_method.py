from sklearn.cluster import KMeans

from sklearn import datasets

from sklearn.metrics.pairwise import euclidean_distances

def calculate_ssd(points, kmax):
    """
    takes in an array points and max number of clusters, kmax and returns 2 arrays, the first containing
    the sum of squared dist value for a given K between the samples and its nearest centroid.
    the second containing the K that corresponds to that value
    """

    sum_sq_dist = []

    K = []

    for k in range(1, kmax):   

        kmeans = KMeans(n_clusters = k, init = "k-means++")

        kmeans.fit(points)

        sum_sq_dist.append(kmeans.inertia_)

        K.append(k)

    return sum_sq_dist, K

def optimal_K(ssd, K):
    """
    finds the optimal K value for a given list of sum of squared distances and list of k values. The optimal 
    K is the one in which maximizes the distance between each K's actual sum of squared distance value and the 
    projected sum of squared distance value given from the linear equation between the first sum of squared value
    and the last.
    """

    slope = (ssd[-1] - ssd[0])/(K[-1] - K[0])

    y_intercept = (ssd[0] - (slope * 1))

    dist_list = []

    for i in range(1, len(K) + 1):

        y_value = ((slope * i) + y_intercept)

        dist = (y_value - ssd[i - 1])

        dist_list.append(dist)

    max_value = max(dist_list)

    max_index = dist_list.index(max_value)

    return (max_index + 1)

#X = import_data("/Users/Andrew/Desktop/CS506/HW1/cs506-homework-1-SunkCostSong/listings.csv")

#scaled = scale(X)

#centers, indices = kmeans_plusplus(scaled, n_clusters=3, random_state=0)

#x, y = calculate_ssd(scaled, 15)

#num_clusters = optimal_K(x, y)

#w,z = kmeans+_+(scaled, num_clusters)

#print(w)




