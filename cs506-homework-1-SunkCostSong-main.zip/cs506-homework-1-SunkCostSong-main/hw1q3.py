import folium
from folium import plugins
from folium.plugins import HeatMap
from folium.plugins import MarkerCluster

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as colors
from matplotlib.patches import Patch
import numpy as np

from hw1q2 import *
from k_means_clustering import *

#a

def generateBaseMap (default_location =[ 40.693943, -73.985880] ) :
    base_map = folium.Map(location=default_location)
    return base_map

# The heat map is not too helpful however, it does show green some spots within the overall blue map which probably indicates 
# that price is higher at that location. Adding a key to the graph would help as well which may help identify clusters, if any. 
# This map could improve by adding more colors to perhaps further differentiate between clusters.

#b

def plot_clustered_data(df, clusters, title, K):
    """
    takes in a data file, an array of cluster id assignments that corresponds to each data point, and a string
    title and outputs a scatter plot organized by clusters (via different colors per cluster), and K number of clusters
    """

    colors = ['blue', 'green', 'gold', 'red', 'gray', 'orange', 'beige', 'purple', 'pink', 'black'] #arbitrary amount, can add more

    for i in range(len(clusters)):

        cluster_id = clusters[i][0]

        plt.plot(df[i][0], df[i][1], "o", color = colors[clusters[i][0]], alpha = 0.75, label='Data Points: Cluster %d' % cluster_id)

    plt.xlabel('Latitude', fontsize=14)
    plt.ylabel('Longitude', fontsize=14)
    plt.title('Clustering for: ' + title, fontsize=16)

    plt.legend(loc=4, framealpha=0.5)
    plt.show(block=True)

#C

def report_cluster_avg_price(data, clusters, K):
    """
    takes in an array of data points, an array of cluster assignments corresponding to each data point
    and K, the number of clusters and returns a list for the average price of each cluster
    """

    cluster_avg_price = []

    for i in range(K):

        cluster_prices = []

        for j in range(len(clusters)):

            if clusters[j][0] == i:

                cluster_prices.append(data[j][2])

        average_price = sum(cluster_prices)/len(cluster_prices)

        cluster_avg_price.append(average_price)

    return cluster_avg_price

#(assumed using optimal K via elbow method with kmax = 11)

#K_Means++:

#Average price for cluster 0: $207.89 per night

#Average price for cluster 1: $99.24 per night

#Average price for cluster 2: $7318.97 per night

##Average price for cluster 3: $103.209 per night

#Average price for cluster 4: $100.36 per night


#Hierarchical:

#Average price for cluster 0: $210.76 per night

#Average price for cluster 1: $103.44 per night

#Average price for cluster 2: $8084.84 per night

##Average price for cluster 3: $86.28 per night

#Average price for cluster 4: $103.22 per night


#GMM:

#Average price for cluster 0: $236.79 per night

#Average price for cluster 1: $85.73 per night

#Average price for cluster 2: $755.79 per night

##Average price for cluster 3: $90.35 per night

#Average price for cluster 4: $91.59 per night


#e

# I don't entirely agree on which parts of NY are more expensive based on the clustering charts . I think that 
# that the clustering analysis is missing a major determinant of price, which is size/space. A listing for an
# entire apartment in Manhattan should have a much higher price than a single room. I don't think the analysis 
# takes that into account


def main():

    data = import_data("/Users/Andrew/Desktop/CS506/HW1/cs506-homework-1-SunkCostSong/listings.csv")

    scaled_data = scale(data)

    ss_dist, k_values = calculate_ssd(scaled_data, 11)   

    K = optimal_K(ss_dist, k_values)

    k_clusters, k_history = k_means_plusplus(scaled_data, K, 10)

    hierarchical_clusters = hierarchical_clustering(scaled_data, K)

    gmm_clusters = gmm_clustering(scaled_data, K)

    plot_clustered_data(data, k_clusters, "K-Means ++", K)

    plot_clustered_data(data, hierarchical_clusters, "Hierarchical", K)

    plot_clustered_data(data, gmm_clusters, "GMM", K)

    

    #k_avg_cluster_price = report_cluster_avg_price(data, k_clusters, K)

   # print("Average prices for each cluster via K-Means++:")

    #print(k_avg_cluster_price)

    #print("\n")

    

    #hierarchical_avg_cluster_price = report_cluster_avg_price(data, hierarchical_clusters, K)

    #print("Average prices for each cluster via Hierarchical:")

    #print(hierarchical_avg_cluster_price)

    #print("\n")

    

    #gmm_avg_cluster_price = report_cluster_avg_price(data, gmm_clusters, K)

    #print("Average prices for each cluster via GMM:")

    #print(gmm_avg_cluster_price)


##### main start##########
if __name__ == '__main__':

    main()
###### main end ##########

#df = pd.read_csv("/Users/Andrew/Desktop/CS506/HW1/cs506-homework-1-SunkCostSong/listings.csv")

#plot_ny_listing_data(df, k_means_pluslus, "kmeans_plusplus")

#plot_ny_listing_data(df, hierarchical_clusters, "hierarchical")

#plot_ny_listing_data(df, gmm_clusters, "gmm")

#def plot_ny_listing_data(df, clusters, title):      #I tried but the html files takes too long to load
    #"""
     #Plot samples and color it according to cluster centroid.
    #:param df: array of data that need to be plotted.
    #:param clusters: array of clusters corresponding to each point in df
    #:param title: string describing the type of clustering
    #"""
    #ny_map = generateBaseMap(default_location =[ 40.693943, -73.985880])

   # colors = ['blue', 'green', 'gold', 'red', 'gray', 'orange', 'beige', 'purple', 'pink', 'black'] #10 colors so assumes max of 10 clusters

   # for index, location in df.iterrows():

     #   plot = [location['latitude'], location['longitude']]

     #   folium.Marker(location).add_to(ny_map)

    #map_title = title + "_ny_listings.html"
    
   # ny_map.save(map_title)
