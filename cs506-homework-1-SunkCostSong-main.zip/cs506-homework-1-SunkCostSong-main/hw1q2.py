from sklearn.preprocessing import StandardScaler

from sklearn.cluster import AgglomerativeClustering

from sklearn.cluster import kmeans_plusplus

from sklearn.mixture import GaussianMixture

import numpy as np

from elbow_method import *

from k_means_clustering import *

#a

#I manually wrote an import_data function that takes in the listings.csv file and created a list of lists
# where there are however many rows as there are data points and column[0] of each row represented
# the latitude as a float, column[1] represented the longitude as a float, and column[2] represented 
# the price as an int.

# I wrote and implemented the elbow method for finding the optimal number of K clusters in
# elbow_method.py which is then used for all three clustering methods. I had to use sklearn's
# StandardScaler methods to scale each of the columns for latitude, longitude, and price which is 
# used in both elbow_method.py and each of the three clustering methods.

# All three clustering functions returns a numpy array that contains the cluster id of each
# data point from listings.csv since the goal is to plot them based on each point's cluster.
# Since each value in the cluster id numpy array corresponds to its respective data point 
# from listings.csv, I can just use the unscaled or scaled version of the data points and 
# its cluster id assignment to plot the data.

# Kmeans_plusplus used sklearn's kmeans_plusplus. Hierarchical clustering used
# sklearn's AgglomerativeClustering over DBScan because DBScan is more susceptible to differences
# in the density of data. GMM uses sklearn's GaussianMixture() method. 

def check_float(value):
    """
    takes in an object and returns true if input can be converted to float
    """

    try:

        float(value)

        return True
    
    except ValueError:

        return False

def import_data(filename):
    """
    takes in a csv file for nyc listings and returns an array of 3D vectors where the
    values: latitude, longitude, and price, are standardized. Listings with missing values
    are excluded from the output
    """

    output_vectors = []     

    file = open(filename, 'r')

    next(file)

    listings = file.readlines()

    prev_list = []      #holds the previous list containing values from previous line

    for listing in listings:

        temp_list = []      #holds list containing values from current line

        processed_list = []     #only holds values pertaining to longitude, latitude, and price

        attributes = listing.split(',')     

        for value in attributes:

            if check_float(value):

                temp_list.append(value)     #creates list with only numbers

            else:

                value = float("NaN")        #if not number, change value to NaN

                temp_list.append(value)
    
        if (len(prev_list) > 0) and (len(prev_list) < 16):    #checks for shortened lines created by .readlines()

           temp_list = prev_list + temp_list    #merges shortened additional lines created by .readlines()

        prev_list = temp_list   #updates prev_list

        if len(temp_list) == 16:    #the least amount of items in temp_list should be 16 given current temp_list did not have to merge with the additional lines created by .readlines()

            processed_list.append(float(temp_list[6]))

            processed_list.append(float(temp_list[7]))

            processed_list.append(int(temp_list[9]))

            output_vectors.append(processed_list)

        elif len(temp_list) > 16:   #temp_list would have more than 16 values if it had to merge with the additional lines created by .readlines()

            processed_list.append(float(temp_list[6 + (len(temp_list) - 16)]))  #the values that were merged come before the index of latitude so, can add to the original index

            processed_list.append(float(temp_list[7 + len(temp_list) - 16]))

            processed_list.append(int(temp_list[9 + (len(temp_list) - 16)]))

            output_vectors.append(processed_list)   #processed list would only include latitude, longitude, price

    file.close

    return output_vectors

def scale(data):
    """
    takes in an array and returns an array where each column has been standardized
    """

    scaler = StandardScaler()

    scaled_data = scaler.fit_transform(data)

    return scaled_data


#K-Means++

#Pros:

#1. The advantage of k-means++ relative to k-means is that it overcomes problem with K-Means by 
#   by choosing initial centroids that are less likely to be outliers

#2  Guaranteed to converge in a finite number of iterations

#3  Generally easier to implement and less computationally expensive than other methpds

#Cons:

#1. Generally produces clsuters of similar sizes

#2  Does not perform well for data with different densities

#3  Tendency to cluster based on globular shapes within the data

def k_means_plusplus(scaled_data, K, n_iter):
    """
    implements kmeans++ cluster initialization using the K optimal number of clusters 
    and returns a list of cluster id assignments that corresponds to each data point 
    in scaled_data and a list of centroids
    """
    centroid_history = []

    centroids, indices = kmeans_plusplus(scaled_data, n_clusters = K, random_state=0)

    clusters = []

    for iteration in range(n_iter):

        centroid_history.append(centroids)

        print("Iteration %d, Finding centroids for all samples..." % iteration)

        clusters = find_closest_centroids(scaled_data, centroids)

        print("Recompute centroids...")

        centroids = get_centroids(scaled_data, clusters)

    return clusters, centroid_history

#Hierarchical (Agglomerative)

#Pros:

#1. Better able to handle any forms of similarity or differences

#2. Produces a hierarchy/dendogram of the clustering

#Cons:

#1. More computationally expensive relative to other methods

#2. Sensitive to outliers

#3. The order of the data can impact the results of clustering

def hierarchical_clustering(scaled_data, K):
    """
    implements hierarchical clustering using the the array with scaled columns, scaled_data, and 
    creates the K optimal number of clusters. returns an array of cluster ids that corresponds to each
    data point in scaled_data
    """

    clustering = AgglomerativeClustering(K, affinity = "euclidean").fit(scaled_data)

    clusters = np.zeros((len(scaled_data), 1), dtype = int)

    labels = clustering.labels_

    for i in range(len(clusters)):

        clusters[i][0] = labels[i]

    return clusters

#GMM

#Pros:

#1. Better able to handle outliers than other methods

#2. Assigns clusters to data points based on likelihood of being generated from each cluster's normal distribution
#   Each cluster assignment is not a definite assignment unlike KMeans

#Cons:

#1. More computationally expensive and complex than other methods

#2. Will always use the total number of components it takes as input 

def gmm_clustering(scaled_data, K):
    """
    takes in an array of scaled columns and uses gmm to return an array of cluster assignments
    for each point in scaled_data
    """

    clusters = np.zeros((len(scaled_data), 1), dtype = int)

    gmm = GaussianMixture(n_components = K, random_state = 0).fit(scaled_data)

    labels = gmm.predict(scaled_data)

    for i in range(len(scaled_data)):

        clusters[i][0] = labels[i]

    return clusters

def main():

    datafile = import_data("/Users/Andrew/Desktop/CS506/HW1/cs506-homework-1-SunkCostSong/listings.csv")

    scaled_data = scale(datafile)

    ss_dist, k_values = calculate_ssd(scaled_data,11)   

    K = optimal_K(ss_dist, k_values)

    k_clusters, k_history = k_means_plusplus(scaled_data, K, 10)

    #print(type(k_clusters))

    #print("\n")

    hierarchical_clusters = hierarchical_clustering(scaled_data, K)

    #print(hierarchical_clusters)

    #print(type(hierarchical_clusters))

    #print("\n")

    gmm_clusters = gmm_clustering(scaled_data, K)

    #print(type(gmm_clusters))

    #print(gmm_clusters)

##### main start##########
if __name__ == '__main__':

    main()
###### main end ##########













        