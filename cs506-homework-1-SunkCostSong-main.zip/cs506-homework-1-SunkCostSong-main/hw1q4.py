#a
import cv2

import numpy as np

def choose_random_centroids(img, K):
    """
    takes in a file opened via cv2 for a picture and K, the number of clusters you want and randomly chooses K centroids amongst the total pixels
    and returns an array for those centroids
    """

    random_row = np.random.permutation(len(img))

    random_column = np.random.permutation(len(img[0]))

    random_centroids = np.zeros((K, len(img[0][0])))

    for i in range(K):

        random_centroids[i] = img[random_row[i]][random_column[i]]

    return random_centroids

def find_closest_centroids(img, centroids):
    """
    takes in a file opened via cv2  and an array of centroids and returns a list of cluster id assigments for each pixel
    """

    array_of_closest_centroids = np.zeros((len(img), len(img[0]), 1), dtype = object)

    for i in range(len(img)):

        closest_centroids = np.zeros((len(img[0]), 1), dtype = int)

        for j in range(len(img[0])):

            min_dist = np.Inf

            for k in range(len(centroids)):

                dist = np.linalg.norm(img[i][j] - centroids[k])

                if dist < min_dist:

                    min_dist = dist

                    closest_centroids[j] = k
            
        array_of_closest_centroids[i] = closest_centroids

    return array_of_closest_centroids

def get_centroids(img, clusters, K):
    """
    takes in a file opened via cv2, an array for cluster assignments for each pixel, and the number
    of clusters, K, and returns an array with K centroids
    """

    centroids = np.zeros((K, len(img[0][0])))

    for i in range(K):

        cluster_samples = []

        for j in range(len(img)):

            for m in range(len(img[0])):

                if clusters[j][m] == i:

                    cluster_samples.append(img[j][m])
        
        mean = np.mean(cluster_samples, axis = 0)

        centroids[i] = mean
    
    return centroids

def run_k_means(samples, initial_centroids, n_iter, K):
    """
    Run K-means algorithm. The number of clusters 'K' is defined by the size of initial_centroids
    :param samples: samples.
    :param initial_centroids: a list of initial centroids.
    :param n_iter: number of iterations.
    :param K: number of iterations.
    :return: a pair of cluster assignment and history of centroids.
    """

    centroid_history = []
    current_centroids = initial_centroids
    clusters = []
    for iteration in range(n_iter):
        centroid_history.append(current_centroids)
        print("Iteration %d, Finding centroids for all samples..." % iteration)
        clusters = find_closest_centroids(samples, current_centroids)
        print("Recompute centroids...")
        current_centroids = get_centroids(samples, clusters, K)

    return clusters, centroid_history

def replace_pixel(img, cluster, centroid_history):
    """
    takes in a file converted via cv2, an array of cluster assignments corresponding to each
    pixel, and an array of cluster centroids for each cluster and returns an image where 
    each pixel has been replaced with its cluster's centroid RGB configuration
    """
    most_recent_centroids = centroid_history[-1]

    manipulated_img = np.copy(img)

    for i in range(len(img)):

       for j in range(len(img[0])):

            for k in range(len(most_recent_centroids)):

                if cluster[i][j] == k:

                    manipulated_img[i][j] = most_recent_centroids[k]

    cv2.imshow('Display Window', manipulated_img) 
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def main():

    img = cv2.imread("/Users/Andrew/Desktop/CS506/HW1/cs506-homework-1-SunkCostSong/test.jpg")

    random_centroids = choose_random_centroids(img, 2)

    # x = [[29,50,51], [67,66,68]] test

    array_cluster_id = find_closest_centroids(img, random_centroids)

    #print(array_cluster_id)

    new_centroids = get_centroids(img, array_cluster_id, random_centroids)

    #print(new_centroids)

    cluster, history = run_k_means(img, x, 10, random_centroids)

    replace_pixel(img, cluster, history)

    #print(history)
    #print(cluster)


##### main start##########
if __name__ == '__main__':

    main()
###### main end ##########
